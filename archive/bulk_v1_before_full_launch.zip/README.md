# Chess difficulty and LLM success

Victor Le - DA401

**My research question:** Does human-rated Lichess puzzle difficulty predict an LLM's success?
I evaluate **GPT-OSS 120B** and **Gemini 3.5 Flash-Lite**. I measure whether each
model selects the official first move, with the board and legal choices supplied.

## My current results

I completed and audited a pilot using the same 60 puzzles for both models.

| Model | Correct first moves | Incorrect legal moves | Format failures |
| --- | --- | --- | --- |
| GPT-OSS 120B | 21/60 (35%) | 38 | 1 |
| Gemini 3.5 Flash-Lite | 32/60 (53.3%) | 26 | 2 |

Both models returned all 60 responses without provider failures. I fitted
separate logistic regressions and descriptive decision trees. Gemini's odds
ratio is 0.51 per 500 rating points (95% interval 0.29-0.90); GPT-OSS's is 0.67
(0.39-1.17). These are exploratory results from a balanced, assisted sample.
I do not claim full puzzle solving, future accuracy or a model-family ranking.

**Start with [03 - Early results](notebooks/03_early_results.ipynb).**
It has two code cells, reads my saved results and makes no API calls.
My three figures are [accuracy](figures/early_results/accuracy.png),
[logistic regression](figures/early_results/logistic_regression.png) and
[decision trees](figures/early_results/decision_trees.png).

## My bulk study is prepared

I froze **1,000 new shared puzzles** with **800 training / 200 test** positions.
I excluded 282 earlier/reserved IDs and 293 prior position keys. My prompts,
model settings, scoring, sampling seeds and analysis plan are frozen in
`experiments/bulk_v1/`. I keep the 60-puzzle pilot separate.

| My operational check | Current status |
| --- | --- |
| Gemini | 8 capability checks and 20 training puzzles completed and audited; resume issued no new generation requests |
| GPT-OSS | Pending: my conservative daily-budget guard is waiting for earlier usage to leave the window |
| Test set | All 200 puzzles remain unused by both models |

**I have prepared the bulk workflow, but I must finish the GPT-OSS operational
check before launching the full collection.** The first saved eligibility time
is **October 22, 2026, 1:17 AM New York time**; the collector may pause again
as further allowance becomes available. This is a local conservative budget
estimate, not a confirmed provider quota-reset time.

1. I open [04 - Bulk collection](notebooks/04_bulk_collection.ipynb), leave `RUN_MODE = "warmup"`, and rerun it after the saved `resume_utc` time. My saved Gemini answers are reused.
2. I check `data/experiments/bulk_v1/warmup_validation.json` for `ready: true` after both models complete the 20-training-puzzle check.
3. I change `RUN_MODE` to `"bulk"` and rerun notebook 04. I set `WAIT_FOR_QUOTA = True` if I want automatic resuming across quota resets while my computer and kernel stay running. Otherwise I rerun after the saved pause time; progress is preserved.
4. I use [05 - Bulk analysis](notebooks/05_bulk_analysis.ipynb) after collection. It fits separate association regressions on all 1,000 audited answers per model, trains each fixed tree only on the 800 training cases, and evaluates its predictions on the 200 held-out cases. It does not preview test performance while collection is incomplete.

I do not retry wrong answers, replace completed responses or tune from test
performance. I budget roughly **2-3 quota days for Gemini** and **9-12 days for
GPT-OSS**, depending on current usage and retries. I verify account limits at
[Groq](https://console.groq.com/docs/rate-limits) and
[Google AI Studio](https://aistudio.google.com/rate-limit).

## My project layout

- `notebooks/01_*` and `02_*`: my completed data inspection and validation; I do not rerun them unless the source changes.
- `notebooks/03_early_results.ipynb`: my completed 60-puzzle pilot results.
- `notebooks/04_bulk_collection.ipynb`: my frozen sample, operational check and resumable bulk collector.
- `notebooks/05_bulk_analysis.ipynb`: my prespecified bulk regressions and held-out tree evaluation.
- `notebooks/08_*`, `09_*`, `10_*`: my validated pilot collection/analysis references, retained to support the bulk implementation.
- `experiments/bulk_v1/`: my frozen bulk config, analysis plan, prompt and lightweight sample index. Earlier numbered protocols are historical.
- `data/`: my raw responses, audits and fitted models. It is Git-ignored, so I back it up separately.
- `figures/early_results/`: my current three figures.
- `writing/`: my three original PDFs, unchanged, and a short README.
- `archive/`: my retired expansion notebooks and superseded figures, with verified hashes.

I use the project's `.venv` kernel. I keep the Groq and Google keys in
Git-ignored `api_key.txt` and `google_api.txt`. I back up `data/experiments/bulk_v1/` and `data/analysis/bulk_v1/` separately because they are Git-ignored. I have not committed or pushed this update.
