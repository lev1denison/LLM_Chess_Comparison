# Figures

Stage numbers match the project README. Current results are the three overview plots in `11_additional_models/`: accuracy, separate logistic regressions and descriptive trees. Gemini is complete; Qwen is explicitly marked incomplete. The original GPT-OSS figures remain in `10_research_analysis/`. Trees describe their training sample; no held-out prediction accuracy is claimed.
