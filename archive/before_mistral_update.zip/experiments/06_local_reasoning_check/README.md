# Stage 06: local reasoning check

Historical checkpoint. Qwen 14B: 4/8 capability checks; gate failed.

Original runnable notebooks and path layout are preserved in archive/before_numbered_stages.zip (and the older legacy archive for stages 03–04). Raw data uses the matching numbered folder under data/experiments/. Internal version IDs and saved paths are historical provenance; do not edit them or rerun in this layout. See archive/README.md to reproduce in a separate copy.
