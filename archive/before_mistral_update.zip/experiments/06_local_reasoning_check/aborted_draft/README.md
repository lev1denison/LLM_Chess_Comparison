# Qwen 14B capability check, version 1

**Superseded before any model response was recorded.** The temperature-zero
reasoning request was aborted after checking the model author's sampling guidance.
See `data/experiments/qwen14b_capability_v1/abort_note.json` and
`archive/qwen14b_capability_v1_notebook.zip`. The active notebook 05 now runs v2,
documented in `experiments/qwen14b_capability_v2/README.md`. Instructions below
describe the preserved draft, not the active run.

Run `notebooks/05_qwen14b_capability.ipynb` with the project environment and Ollama.
No other notebook needs to be rerun. The notebook is resumable and preserves every
previous experiment. A changed model digest, prompt, configuration or executable
cell requires a new experiment version.

The installed `qwen3:14b` Q4_K_M deployment uses thinking enabled, at most 8192
generated tokens, 12288 context, temperature 0 and seed 401. Both thinking and the
final answer use the generation budget. Requests are independent; no tools,
engine scores or official solutions enter the input.

Eight diagnostic tasks check side to move, any legal move and mate in one.
Fixtures include horizontal/color mirrors; they are correlated sanity checks,
not eight independent research observations. Mate answers are verified by chess
rules. Output is structured JSON, with moves constrained to legal UCI choices.

The pre-specified gate requires all eight completed requests, both side checks,
both legal checks and at least two of four mates correct. After two consecutive
generation-limit or infrastructure failures, stop the diagnostic stage early.
Such an early stop is an incomplete capability check, not proof of inability.

Only after passing, evaluate 24 fresh puzzles, four in each rating by solution-
length cell. Exclude all 198 prior original, reserved and first-move sample IDs.
Compare exact first-move agreement with the uniform random legal-choice baseline
using a Poisson-binomial tail calculation. This is an exploratory one-model check;
do not fit new classifiers or interpret it as a controlled effect of model size.

Raw records, manifest, gate decision, runtime details and audit:
`data/experiments/qwen14b_capability_v1/`. Written findings:
`writing/qwen14b_capability_report.md`. Raw data is Git-ignored and needs backup.

Official references: [chat API](https://docs.ollama.com/api/chat) and
[thinking controls](https://docs.ollama.com/capabilities/thinking).
