# Stage 11: additional model families

Run notebooks/11_additional_models.ipynb. Qwen and Gemini have separate raw logs and artifacts under this stage, with one shared frozen 60-puzzle sample and three overview figures. Earlier GPT-OSS results are read as a reference and never overwritten. The notebook documents capability/data gates, individual deployment settings and limitations.

Gemini completed: 32/60 correct (53.3%), 26 incorrect legal moves and two format failures; all 68 saved responses passed audit. Its regression and tree are saved. Optional Qwen passed capability but was stopped at five research responses after repeated Groq output-token limits; no Qwen models were fitted. The interruption and offline saved-result analysis are recorded in `data/experiments/11_additional_models/collection_pause.json`. No prompt or generation settings changed. Rerunning collection attempts pending Qwen cases; review saved results first.
