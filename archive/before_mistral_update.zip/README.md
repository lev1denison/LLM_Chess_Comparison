# Chess difficulty and LLM success

Victor Le - DA401

**Question:** Does human-rated Lichess puzzle difficulty predict an LLM's success?
We measure assisted exact first-move correctness, not the whole solution sequence.
One LLM is sufficient; comparing models is optional.

## Start here

**Current step: 11 - Review Gemini's early results.**
Open [11 - Additional model results](notebooks/11_additional_models.ipynb).
Gemini 3.5 Flash-Lite completed the same 60 puzzles: **32 correct (53.3%)**,
26 incorrect legal moves and two format failures. All 68 responses, including
eight capability checks, passed audit. GPT-OSS remains **21/60 (35%)**.

View the [accuracy overview](figures/11_additional_models/accuracy.png),
[logistic regressions](figures/11_additional_models/logistic_regression.png)
and [decision trees](figures/11_additional_models/decision_trees.png).
Gemini's rating odds ratio is 0.51 per 500 points (95% interval 0.29-0.90).
These are exploratory assisted first-move results; the shared sample and
different deployment settings do not establish a model-family ranking.
Optional Qwen collection was paused at 5/60 responses after repeated Groq
output-token limits; it has no fitted models. Next: review these results,
then freeze a larger, fresh validation study.

## Project history

Numbers match across experiments, data and figures.

| Stage | Work | Status |
| --- | --- | --- |
| 01 | [Data inspection](notebooks/01_data_inspection.ipynb) | Complete |
| 02 | [Chess validation](notebooks/02_chess_validation.ipynb) | 6,157,341 puzzles validated |
| 03 | Local full-sequence pilot | Historical: 0/225 correct sequences |
| 04 | Local prompt revision | Historical: no complete solutions |
| 05 | Local first-move pilot | Historical: 6/144 correct; preliminary classifiers |
| 06 | Local reasoning check | Historical: Qwen 14B failed readiness |
| 07 | Hosted first-move pilot | Historical: 11 correct, 4 incorrect, 9 no answer /24 |
| 08 | [Hosted reliability](notebooks/08_check_hosted_reliability.ipynb) | Complete: low-effort deployment passed |
| 09 | [Fresh research sample](notebooks/09_collect_research_sample.ipynb) | Complete: 60 fresh puzzles, audited |
| 10 | Research analysis | Complete: original GPT-OSS regression and tree preserved |
| 11 | [Additional model results](notebooks/11_additional_models.ipynb) | Gemini complete; regression/tree ready; optional Qwen paused |

## Folders and running

- `notebooks/`: data preparation and the 08 -> 09 -> 10 -> 11 workflow.
- `experiments/`: numbered protocols; `stage_index.json` maps old names to new.
- `data/`: source data, responses, samples, audits and models. Git-ignored; back up separately.
- `figures/`: numbered plots; current overview is in `11_additional_models/`.
- `writing/`: your three PDFs and README; six Markdown reports were deleted.
- `archive/`: verified older notebooks/code and restoration instructions.

Use the project's `.venv` kernel. Keys stay in Git-ignored `api_key.txt` (Groq)
and `google_api.txt` (Google); never commit or share them. Review notebook 11's
saved plots without rerunning collection: its collection cell also retries
pending Qwen cases. Gemini's collection completed before the optional Qwen run
was stopped; analysis was rendered offline from saved responses. Earlier
answers are cached on resume. Notebook 10 has no API calls. Run 01-02 again
only if source data or validation changes.

Historical data, figures and PDFs were preserved. Older experiment notebooks
were archived so they no longer look like current steps. File moves and checks
are recorded in `archive/reorganization_audit.json`. Frozen internal version IDs
remain unchanged. No commit or push was performed in this update.
