# Research writing

My proposal, research design and literature review PDFs are kept here.
Generated Markdown reports were removed. Current status and next steps are in the project README; detailed methods and results are in the notebooks.
