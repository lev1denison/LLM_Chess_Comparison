# Historical checkpoints

`before_numbered_stages.zip` preserves notebooks 01–06, experiment protocols,
figures and the root README exactly as they were before the numbered layout.
Every member was verified against `before_numbered_stages_hashes.json`.
It contains no API key, raw data or deleted writing reports.

For reproduction, extract that ZIP into a separate working copy, copy source
data and raw outputs into it, and reverse `historical_path_mapping` from
`experiments/stage_index.json` (longest destination paths first, so the aborted
draft is restored before its parent). Then use the original notebook paths.
Restore the earlier `code/` layout from `pre_first_move_code.zip` for stages
03–04; its checksums are in `code_snapshot_hashes.json`. The additional Qwen
draft ZIP preserves the aborted, never-completed temperature-zero run.

`reorganization_audit.json` records moves, verified files, removed writing
Markdown names and unchanged PDF hashes. Internal version names in raw logs
and manifests are historical identifiers and have intentionally been kept.
Archives contain code and metadata; back up Git-ignored `data/` separately.

`stage08_strict_output_notebook.zip` preserves the first reliability notebook and
its protocol. To reproduce that run in a separate copy, restore the ZIP and copy
the contents of `data/experiments/08_hosted_reliability/01_strict_output/` to
`data/experiments/08_hosted_reliability/` in that copy. Keep the numbered stage
03-07 data folders for this newer notebook. The current stage-08 notebook records
offline imports and preserves the original strict scores alongside normalized ones.
