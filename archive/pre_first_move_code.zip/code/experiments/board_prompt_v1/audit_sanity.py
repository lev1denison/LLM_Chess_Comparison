"""Verify sanity scores independently against fixed chess fixtures."""
import json
from experiment import OUT, read_rows, sanity_cases, write_json

cases={name:(board,task) for name,board,task in sanity_cases()}
logs={r['trial_id']:r for r in read_rows('requests.jsonl') if r['stage']=='sanity' and 'response' in r}
checked=0
latest={}
for row in read_rows('outcomes.jsonl'):
    if row['stage']=='sanity':latest[(row['llm_name'],row['puzzle_id'])]=row
for row in latest.values():
    if row['status']!='completed':
        assert row['success'] is None
        continue
    board,task=cases[row['puzzle_id']]
    log=logs[row['trial_id']]
    assert board.fen() in log['request']['messages'][0]['content']
    try:
        value=json.loads(log['response']['message']['content'])
        if task=='side':expected=int(value=={'side':'white' if board.turn else 'black'})
        else:
            import chess
            assert isinstance(value,dict) and set(value)=={'move'}
            move=chess.Move.from_uci(value['move'])
            legal=move in board.legal_moves
            copy=board.copy()
            if legal:copy.push(move)
            expected=int(legal and (task=='legal' or copy.is_checkmate()))
        if log['response'].get('done_reason')=='length':expected=0
    except (ValueError,KeyError,TypeError,AssertionError):expected=0
    assert row['success']==expected
    checked+=1
assert len(latest)==18 and checked==18
write_json(OUT/'sanity_audit_summary.json',{'sanity_outcomes_verified':checked,'status':'passed'})
print('All 18 sanity scores verified.')
