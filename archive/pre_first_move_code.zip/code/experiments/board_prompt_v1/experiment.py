"""Versioned prompt development and fresh evaluation, independent of the old pilot.

Run with the project Python: experiment.py prepare|develop|evaluate|audit
"""
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import time
import uuid
import chess
import numpy as np
import pandas as pd
import requests

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = ROOT / 'data/experiments/board_prompt_v1'
CONFIG = json.loads((HERE / 'config.json').read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')


def read_rows(name):
    path = OUT / name
    return [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s.strip()] if path.exists() else []


def append(name, row):
    with (OUT / name).open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(row) + '\n')
        stream.flush()


def protected_files():
    paths = [ROOT / 'code' / name for name in ['chess_prompt_v1.txt','llm_config.json','run_llm_puzzles.py',
             'analyze_early_results.py','early_results.ipynb','prepare_sample.ipynb']]
    for folder in ['data/experiments/local_pilot_v2','data/samples/pilot_v1',
                   'data/analysis/local_pilot_v2','figures/local_pilot_v2']:
        paths.extend(p for p in (ROOT / folder).rglob('*') if p.is_file())
    return {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(paths)}


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / 'preparation.json').exists():
        assert protected_files() == json.loads((OUT / 'checkpoint_hashes.json').read_text())
        print('Existing preparation retained.')
        return
    assert not (OUT / 'outcomes.jsonl').exists()
    write_json(OUT / 'checkpoint_hashes.json', protected_files())
    original = pd.read_csv(ROOT / 'data/samples/pilot_v1/pilot_puzzles.csv', dtype={'puzzle_id':str})
    development = pd.concat([original.loc[original.rating_stratum.eq(group)].sample(
        CONFIG['development_per_stratum'], random_state=CONFIG['seed']) for group in ['low','middle','high']])
    development.sort_values('puzzle_id').to_csv(OUT / 'development_puzzles.csv',index=False)
    excluded = set(original.puzzle_id)
    old_meta = json.loads((ROOT / 'data/samples/pilot_v1/pilot_sampling_metadata.json').read_text())
    lower, upper = [old_meta['rating_cutoffs'][k] for k in ['lower_inclusive','upper_inclusive']]
    rng = np.random.default_rng(CONFIG['seed'])
    candidates = {name:pd.DataFrame() for name in ['low','middle','high']}
    counts = defaultdict(int)
    for chunk in pd.read_csv(ROOT / 'data/validation/full/validated_features.csv',chunksize=100_000,dtype={'puzzle_id':str}):
        frame = chunk.loc[~chunk.puzzle_id.isin(excluded)].copy()
        frame['rating_stratum'] = np.where(frame.puzzle_rating <= lower,'low',np.where(frame.puzzle_rating <= upper,'middle','high'))
        frame['_priority'] = rng.random(len(frame))
        for name in candidates:
            group = frame.loc[frame.rating_stratum.eq(name)]
            counts[name] += len(group)
            candidates[name] = pd.concat([candidates[name],group.nsmallest(CONFIG['evaluation_per_stratum'],'_priority')],ignore_index=True).nsmallest(CONFIG['evaluation_per_stratum'],'_priority')
    fresh = pd.concat(candidates.values(),ignore_index=True).drop(columns='_priority')
    wanted = set(fresh.puzzle_id)
    assert len(wanted) == 75 and not wanted & excluded
    matches = []
    source = ROOT / 'data/lichess_db_puzzle.csv.zst'
    assert digest(source) == old_meta['source_sha256']
    for chunk in pd.read_csv(source,compression='zstd',chunksize=100_000,dtype=str,keep_default_na=False,
                             usecols=['PuzzleId','FEN','Moves','GameUrl']):
        found = chunk.loc[chunk.PuzzleId.isin(wanted)]
        if not found.empty:
            matches.append(found)
    answers = pd.concat(matches).rename(columns={'PuzzleId':'puzzle_id','FEN':'original_fen','Moves':'official_moves','GameUrl':'game_url'})
    fresh = fresh.merge(answers,on='puzzle_id',validate='one_to_one')
    def phase(text):
        tags = set(text.split()) & {'opening','middlegame','endgame'}
        return next(iter(tags)) if len(tags)==1 else 'unknown' if not tags else 'mixed'
    fresh['game_phase'] = fresh.themes.map(phase)
    for row in fresh.itertuples(index=False):
        board = chess.Board(row.original_fen)
        assert board.is_valid()
        for i, move in enumerate(row.official_moves.split()):
            assert chess.Move.from_uci(move) in board.legal_moves
            board.push_uci(move)
            if i == 0:
                assert board.fen() == row.solver_fen
        assert len(row.official_moves.split()[1::2]) == row.total_solver_moves
    fresh.sort_values('puzzle_id').to_csv(OUT / 'evaluation_puzzles.csv',index=False)
    write_json(OUT / 'preparation.json',{'seed':CONFIG['seed'],'development_n':len(development),'evaluation_n':len(fresh),
        'source_sha256':old_meta['source_sha256'],'cutoffs':[lower,upper],'eligible_counts_excluding_old_pilot':dict(counts),
        'excluded_original_ids':sorted(excluded),'filters':'All validated puzzles, matching original pilot eligibility',
        'development_sha256':digest(OUT / 'development_puzzles.csv'),'evaluation_sha256':digest(OUT / 'evaluation_puzzles.csv')})
    print('Prepared 12 development puzzles and 75 fresh evaluation puzzles, excluding all original 75.')


def piece_list(board):
    lines = []
    for color in [chess.WHITE,chess.BLACK]:
        values = [f'{chess.piece_name(piece.piece_type)} {chess.square_name(square)}'
                  for square,piece in sorted(board.piece_map().items()) if piece.color == color]
        lines.append(('White' if color else 'Black')+' pieces: '+', '.join(values))
    return '\n'.join(lines)


def move_body(board, condition, model, thinking=False):
    assisted = condition == 'legal_choices_json'
    path = HERE / ('legal_choices_prompt.txt' if assisted else 'piece_list_prompt.txt')
    choices = sorted(move.uci() for move in board.legal_moves)
    assert choices
    prompt = path.read_text().format(fen=board.fen(),side='White' if board.turn else 'Black',
                                   pieces=piece_list(board),legal_moves=', '.join(choices))
    field = {'type':'string','enum':choices} if assisted else {'type':'string','pattern':'^[a-h][1-8][a-h][1-8][qrbn]?$'}
    body = {'model':model,'messages':[{'role':'user','content':prompt}], 'stream':False,'keep_alive':'5m',
        'options':CONFIG['qwen_reasoning_options'] if thinking else CONFIG['direct_options'],
        'format':{'type':'object','properties':{'move':field},'required':['move'],'additionalProperties':False}}
    if model == 'qwen3:8b':
        body['think'] = thinking
    return body


def parse_move(board, payload, expected=None):
    if payload.get('done_reason') == 'length':
        return 'generation_limit',None
    try:
        value = json.loads(payload['message']['content'])
        assert isinstance(value,dict) and set(value) == {'move'}
        text = value['move']
        assert isinstance(text,str) and re.fullmatch('[a-h][1-8][a-h][1-8][qrbn]?',text)
        move = chess.Move.from_uci(text)
    except (ValueError,KeyError,AssertionError,TypeError):
        return 'unparseable',None
    if move not in board.legal_moves:
        return 'illegal_move',text
    return ('correct' if expected is None or text == expected else 'legal_incorrect'),text


def freeze():
    assert protected_files() == json.loads((OUT / 'checkpoint_hashes.json').read_text()), 'Original checkpoint changed'
    preparation = json.loads((OUT / 'preparation.json').read_text())
    for stage in ['development','evaluation']:
        assert digest(OUT / f'{stage}_puzzles.csv') == preparation[f'{stage}_sha256']
    response = requests.get(CONFIG['base_url']+'/api/tags',timeout=10);response.raise_for_status()
    tags = {m['name']:m for m in response.json()['models']}
    models = {}
    for name in CONFIG['models']:
        assert name in tags
        response = requests.post(CONFIG['base_url']+'/api/show',json={'model':name},timeout=15);response.raise_for_status()
        details = response.json()
        models[name] = {'digest':tags[name]['digest'],'details':details.get('details'),'capabilities':details.get('capabilities')}
    # Freeze executable logic as well as configuration before the first inference.
    protocol = {'config':CONFIG,'prompts':{p.name:p.read_text() for p in HERE.glob('*_prompt.txt')},
                'runner_sha256':digest(Path(__file__)),'models':models,'preparation':preparation}
    path = OUT / 'manifest.json'
    if path.exists():
        assert json.loads(path.read_text()) == protocol, 'Protocol changed; use a new version'
    else:
        write_json(path,protocol)


def call(body, context):
    for retry in range(2):
        log = dict(context, retry=retry,timestamp_utc=datetime.now(timezone.utc).isoformat(),request=body)
        started = time.perf_counter()
        try:
            response = requests.post(CONFIG['base_url']+'/api/chat',json=body,timeout=(10,300));response.raise_for_status()
            payload = response.json()
            if not payload.get('done') or 'content' not in payload.get('message',{}):
                raise ValueError('Incomplete provider response')
            log['response'] = payload
        except (requests.RequestException,ValueError) as error:
            log['error_type'] = type(error).__name__
            log['http_status'] = getattr(getattr(error,'response',None),'status_code',None)
        log['elapsed_seconds'] = time.perf_counter()-started
        append('requests.jsonl',log)
        if 'response' in log:
            return log['response']
    return None


def finished():
    return {(r['stage'],r['condition'],r['llm_name'],r['puzzle_id']) for r in read_rows('outcomes.jsonl') if r['status']=='completed'}


def trial(row, model, condition, stage, thinking=False):
    key = (stage,condition,model,row.puzzle_id)
    if key in finished():
        return
    trial_id = str(uuid.uuid4())
    board = chess.Board(row.solver_fen)
    official = row.official_moves.split()[1:]
    started = time.perf_counter()
    category,status,correct = 'success','completed',0
    for index in range(0,len(official),2):
        payload = call(move_body(board,condition,model,thinking),
                       {'trial_id':trial_id,'stage':stage,'condition':condition,'llm_name':model,
                        'puzzle_id':row.puzzle_id,'solver_turn':index//2+1})
        if payload is None:
            status,category='infrastructure_error','request_failed'
            break
        category,move=parse_move(board,payload,official[index])
        if category != 'correct':
            break
        correct += 1
        board.push_uci(move)
        if index+1 < len(official):
            board.push_uci(official[index+1])
    if status=='completed' and correct==row.total_solver_moves:
        category='success'
    result = {'trial_id':trial_id,'stage':stage,'condition':condition,'llm_name':model,'puzzle_id':row.puzzle_id,
        'status':status,'success':int(category=='success') if status=='completed' else None,
        'failure_type':category,'correct_solver_moves':correct,'required_solver_moves':row.total_solver_moves,
        'elapsed_seconds':round(time.perf_counter()-started,3),'thinking':thinking}
    append('outcomes.jsonl',result)
    print(f'{stage} {condition} {model} {row.puzzle_id}: {category} ({result["elapsed_seconds"]:.1f}s)',flush=True)


def sanity_cases():
    after = chess.Board();after.push_uci('e2e4')
    mate = chess.Board('7k/8/5KQ1/8/8/8/8/8 w - - 0 1')
    return [('side_white',chess.Board(),'side'),('side_black',after,'side'),
            ('legal_white',chess.Board(),'legal'),('legal_black',after,'legal'),
            ('mate_white',mate,'mate'),('mate_black',mate.mirror(),'mate')]


def sanity(model):
    for name,board,task in sanity_cases():
        key = ('sanity',task,model,name)
        if key in finished():
            continue
        trial_id = str(uuid.uuid4())
        body = move_body(board,'piece_list_json',model)
        if task == 'side':
            # Do not reveal side in text or a "White to move" line; it is encoded only in the FEN.
            body['messages']=[{'role':'user','content':f'Which side moves next in this FEN? {board.fen()}\n'+piece_list(board)+'\nReturn JSON with only key "side": "white" or "black".'}]
            body['format']={'type':'object','properties':{'side':{'type':'string','enum':['white','black']}},'required':['side'],'additionalProperties':False}
        elif task == 'legal':
            body['messages'][0]['content'] = body['messages'][0]['content'].replace('Solve this chess puzzle','Choose any legal move, not necessarily the best. Examine this position')
        else:
            mating = []
            for move in list(board.legal_moves):
                copy = board.copy();copy.push(move)
                if copy.is_checkmate():mating.append(move.uci())
            assert mating and board.is_valid()
            body['messages'][0]['content'] = body['messages'][0]['content'].replace('Find the best next move.','Find a move that delivers checkmate immediately.')
        payload=call(body,{'trial_id':trial_id,'stage':'sanity','condition':task,'llm_name':model,'puzzle_id':name,'solver_turn':1})
        success=None;category='request_failed'
        if payload is not None:
            if task=='side':
                try:
                    value=json.loads(payload['message']['content'])
                    success=int(value=={'side':'white' if board.turn else 'black'} and payload.get('done_reason')!='length')
                except (ValueError,KeyError,TypeError):success=0
                category='success' if success else 'incorrect_side_or_format'
            else:
                category,move=parse_move(board,payload)
                if category=='correct':
                    if task=='mate':
                        copy=board.copy();copy.push_uci(move);success=int(copy.is_checkmate())
                        category='success' if success else 'not_checkmate'
                    else:success=1;category='success'
                else:success=0
        append('outcomes.jsonl',{'trial_id':trial_id,'stage':'sanity','condition':task,'llm_name':model,'puzzle_id':name,
            'status':'completed' if payload is not None else 'infrastructure_error','success':success,'failure_type':category})
        print(f'sanity {model} {name}: {category}',flush=True)


def select():
    rows=pd.DataFrame(read_rows('outcomes.jsonl'))
    if rows.empty:return None
    rows=rows.drop_duplicates(['stage','condition','llm_name','puzzle_id'],keep='last')
    rows=rows.loc[rows.stage.eq('development')]
    candidates=[];detail={}
    rule=CONFIG['selection_rule']
    for condition in rule['eligible_conditions']:
        group=rows.loc[rows.condition.eq(condition)]
        bad=group.failure_type.isin(['unparseable','illegal_move','generation_limit'])
        solves=int(group.success.fillna(0).sum())
        distinct=int(group.loc[group.success.eq(1),'puzzle_id'].nunique())
        valid=float((~bad).mean()) if len(group) else 0
        ready=len(group)==36 and group.status.eq('completed').all() and solves>=rule['minimum_full_solves'] and distinct>=rule['minimum_distinct_solved_puzzles'] and valid>=rule['minimum_format_and_legality_rate']
        detail[condition]={'n':len(group),'solves':solves,'distinct_solved_puzzles':distinct,'format_and_legality_rate':valid,'ready':bool(ready)}
        if ready:candidates.append((solves,condition=='piece_list_json',condition))
    chosen=max(candidates)[2] if candidates else None
    result={'selected_condition':chosen,'development':detail,'rule':rule,
            'status':'Ready for one fresh evaluation' if chosen else 'No condition met readiness criteria; evaluation not run'}
    write_json(OUT/'selection.json',result)
    print(json.dumps(result,indent=2),flush=True)
    return chosen


def collect(stage):
    freeze()
    dev=pd.read_csv(OUT/'development_puzzles.csv',dtype={'puzzle_id':str})
    if stage=='development':
        for model in CONFIG['models']:
            sanity(model)
            for condition in CONFIG['selection_rule']['eligible_conditions']:
                for row in dev.itertuples(index=False):trial(row,model,condition,'development')
            if model=='qwen3:8b':
                probe=dev.groupby('rating_stratum',sort=True).head(1)
                for row in probe.itertuples(index=False):trial(row,model,'legal_choices_json','reasoning_probe',thinking=True)
            unload(model)
        select()
    else:
        condition=select()
        if condition is None:return
        selected=json.loads((OUT/'selection.json').read_text())
        freeze_path=OUT/'evaluation_protocol.json'
        if freeze_path.exists():assert json.loads(freeze_path.read_text())==selected
        else:write_json(freeze_path,selected)
        fresh=pd.read_csv(OUT/'evaluation_puzzles.csv',dtype={'puzzle_id':str})
        for model in CONFIG['models']:
            for row in fresh.itertuples(index=False):trial(row,model,condition,'evaluation')
            unload(model)


def unload(model):
    response=requests.post(CONFIG['base_url']+'/api/generate',json={'model':model,'keep_alive':0},timeout=60)
    response.raise_for_status()


def audit():
    assert protected_files()==json.loads((OUT/'checkpoint_hashes.json').read_text())
    rows=pd.DataFrame(read_rows('outcomes.jsonl')).drop_duplicates(['stage','condition','llm_name','puzzle_id'],keep='last')
    logs=defaultdict(list)
    for row in read_rows('requests.jsonl'):
        if 'response' in row:logs[row['trial_id']].append(row)
    tables={s:pd.read_csv(OUT/f'{s}_puzzles.csv',dtype={'puzzle_id':str}).set_index('puzzle_id') for s in ['development','evaluation']}
    for row in rows.loc[~rows.stage.eq('sanity')].itertuples(index=False):
        puzzle=tables['evaluation' if row.stage=='evaluation' else 'development'].loc[row.puzzle_id]
        board=chess.Board(puzzle.solver_fen);official=puzzle.official_moves.split()[1:]
        correct=0;category=None
        for index,log in enumerate(logs[row.trial_id]):
            expected=move_body(board,row.condition,row.llm_name,bool(row.thinking))
            assert log['request']==expected
            category,move=parse_move(board,log['response'],official[2*index])
            if category!='correct':
                assert index==len(logs[row.trial_id])-1
                break
            correct+=1;board.push_uci(move)
            if 2*index+1<len(official):board.push_uci(official[2*index+1])
        assert correct==row.correct_solver_moves
        if row.status=='completed':
            success=int(correct==puzzle.total_solver_moves)
            assert row.success==success and row.failure_type==('success' if success else category)
    result={'scored_outcomes_checked':int((~rows.stage.eq('sanity')).sum()),
            'sanity_outcomes_recorded':int(rows.stage.eq('sanity').sum()),
            'original_checkpoint_hashes_match':True,'status':'passed'}
    write_json(OUT/'audit_summary.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['prepare','develop','evaluate','audit'])
    action=parser.parse_args().action
    {'prepare':prepare,'develop':lambda:collect('development'),'evaluate':lambda:collect('evaluation'),'audit':audit}[action]()
