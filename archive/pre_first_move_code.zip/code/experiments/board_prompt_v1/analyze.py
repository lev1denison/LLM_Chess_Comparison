"""Report development separately from fresh evaluation; preserve baseline outputs."""
from pathlib import Path
import json
import warnings
import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, roc_auc_score, brier_score_loss
from experiment import ROOT, OUT, read_rows, write_json

ANALYSIS=ROOT/'data/analysis/board_prompt_v1'
FIG=ROOT/'figures/board_prompt_v1'


def planned_split():
    fresh=pd.read_csv(OUT/'evaluation_puzzles.csv',dtype={'puzzle_id':str})
    training=set(pd.concat([f.sample(20,random_state=407) for _,f in fresh.groupby('rating_stratum')]).puzzle_id)
    split=fresh[['puzzle_id','rating_stratum']].copy()
    split['partition']=np.where(split.puzzle_id.isin(training),'train','test')
    path=OUT/'planned_evaluation_split.csv'
    if path.exists():
        pd.testing.assert_frame_equal(pd.read_csv(path,dtype={'puzzle_id':str}),split)
    else:
        assert not any(r['stage']=='evaluation' for r in read_rows('outcomes.jsonl'))
        split.to_csv(path,index=False)
    return split


def fit_models(data,split,report):
    data=data.merge(split[['puzzle_id','partition']],on='puzzle_id',validate='many_to_one')
    train=data.loc[data.partition.eq('train')];test=data.loc[data.partition.eq('test')]
    assert not set(train.puzzle_id)&set(test.puzzle_id)
    counts=train.success.value_counts()
    report['training_class_counts']={str(k):int(v) for k,v in counts.items()}
    if len(counts)<2 or min(counts)<10 or len(test)==0:
        report['model_status']='Deferred: fixed training set needs at least 10 successes and 10 failures for even preliminary predictive models. No split was redrawn.'
        return
    numeric=['puzzle_rating','total_solver_moves','legal_moves','piece_count','material_balance']
    categorical=['llm_name'];columns=numeric+categorical
    models={'majority_baseline':DummyClassifier(strategy='most_frequent'),
            'logistic_regression':LogisticRegression(max_iter=2000,random_state=407),
            'decision_tree':DecisionTreeClassifier(max_depth=3,min_samples_leaf=10,random_state=407)}
    predictions=test[['puzzle_id','llm_name','success']].copy();metrics=[]
    for name,model in models.items():
        prep=ColumnTransformer([('numeric',StandardScaler(),numeric),
                               ('model_identity',OneHotEncoder(drop='first',handle_unknown='ignore'),categorical)])
        pipe=Pipeline([('features',prep),('model',model)])
        pipe.fit(train[columns],train.success)
        prob=pipe.predict_proba(test[columns])[:,1];pred=pipe.predict(test[columns])
        metrics.append({'model':name,'test_n':len(test),'accuracy':accuracy_score(test.success,pred),
            'balanced_accuracy':balanced_accuracy_score(test.success,pred),
            'roc_auc':float(roc_auc_score(test.success,prob)) if test.success.nunique()==2 else None,
            'brier_score':brier_score_loss(test.success,prob)})
        predictions[name+'_probability']=prob
        joblib.dump(pipe,ANALYSIS/(name+'.joblib'))
        names=pipe.named_steps['features'].get_feature_names_out()
        if name=='logistic_regression':
            pd.DataFrame({'feature':names,'standardized_penalized_coefficient':model.coef_[0]}).to_csv(ANALYSIS/'logistic_coefficients.csv',index=False)
        if name=='decision_tree':
            fig,ax=plt.subplots(figsize=(16,7))
            plot_tree(model,feature_names=names,class_names=['failure','success'],filled=True,rounded=True,ax=ax)
            ax.set_title('Fresh evaluation: training-fitted decision tree (numeric splits standardized)')
            fig.tight_layout();fig.savefig(FIG/'decision_tree.png',dpi=160);plt.close(fig)
    pd.DataFrame(metrics).to_csv(ANALYSIS/'model_metrics.csv',index=False)
    predictions.to_csv(ANALYSIS/'test_predictions.csv',index=False)
    report['model_status']='Preliminary L2 logistic regression and shallow decision tree fitted; exploratory, small sample.'
    report['metrics']=metrics
    if min(data.success.value_counts())>=20 and data.groupby('llm_name').success.nunique().min()==2:
        try:
            data=data.copy();data['rating_100']=data.puzzle_rating/100
            with warnings.catch_warnings(record=True) as caught:
                fit=smf.glm('success ~ rating_100 + C(llm_name)',data=data,family=sm.families.Binomial()).fit(
                    cov_type='cluster',cov_kwds={'groups':data.puzzle_id})
            if not fit.converged or caught:raise ValueError('Unstable inference')
            ci=fit.conf_int()
            pd.DataFrame({'coefficient':fit.params,'odds_ratio':np.exp(fit.params),
                'or_ci_lower':np.exp(ci[0]),'or_ci_upper':np.exp(ci[1]),'p_value':fit.pvalues}).to_csv(ANALYSIS/'clustered_rating_logistic.csv')
            report['inference_status']='Exploratory rating+LLM logistic GLM on all fresh data; standard errors clustered by puzzle. Separate from predictive holdout evaluation.'
        except Exception as error:report['inference_status']='Deferred: '+type(error).__name__
    else:report['inference_status']='Deferred: sparse or separated model-specific outcomes.'


def markdown_table(frame):
    # Avoid optional tabulate dependency in reproducible reporting.
    values=frame.reset_index().astype(str)
    return '| '+' | '.join(values.columns)+' |\n| '+' | '.join(['---']*len(values.columns))+' |\n'+'\n'.join('| '+' | '.join(row)+' |' for row in values.values.tolist())


def main():
    ANALYSIS.mkdir(parents=True,exist_ok=True);FIG.mkdir(parents=True,exist_ok=True)
    split=planned_split()
    rows=pd.DataFrame(read_rows('outcomes.jsonl')).drop_duplicates(['stage','condition','llm_name','puzzle_id'],keep='last')
    rows.to_csv(ANALYSIS/'all_outcomes.csv',index=False)
    scored=rows.loc[rows.status.eq('completed')].copy()
    scored['success']=scored.success.astype(int)
    summary=scored.groupby(['stage','condition','llm_name']).agg(n=('success','size'),solved=('success','sum'),solve_rate=('success','mean'))
    summary.to_csv(ANALYSIS/'condition_results.csv')
    sanity=scored.loc[scored.stage.eq('sanity')]
    sanity_summary=sanity.groupby(['condition','llm_name']).agg(n=('success','size'),passed=('success','sum'))
    sanity_summary.to_csv(ANALYSIS/'sanity_results.csv')
    failure=pd.crosstab([scored.stage,scored.condition,scored.llm_name],scored.failure_type)
    failure.to_csv(ANALYSIS/'failure_counts.csv')
    choice_rows=[]
    for request in read_rows('requests.jsonl'):
        if request['stage']!='development' or request['condition']!='legal_choices_json' or 'response' not in request:
            continue
        choices=request['request']['format']['properties']['move']['enum']
        try:move=json.loads(request['response']['message']['content'])['move']
        except (ValueError,KeyError,TypeError):move=None
        choice_rows.append({'llm_name':request['llm_name'],'puzzle_id':request['puzzle_id'],
            'solver_turn':request['solver_turn'],'n_legal_choices':len(choices),
            'selected_first_alphabetical_choice':move==choices[0],
            'selected_choice_index':choices.index(move) if move in choices else None})
    if choice_rows:
        choices=pd.DataFrame(choice_rows)
        choices.to_csv(ANALYSIS/'legal_choice_diagnostics.csv',index=False)
    dev=scored.loc[scored.stage.eq('development')].copy()
    dev_features=pd.read_csv(OUT/'development_puzzles.csv',dtype={'puzzle_id':str})
    dev=dev.merge(dev_features,on='puzzle_id',validate='many_to_one')
    dev.to_csv(ANALYSIS/'development_table.csv',index=False)
    # Post-hoc descriptive diagnostic only; it does not replace full-line success
    # or enter protocol selection/classifier fitting.
    partial=dev.copy()
    partial['first_move_correct']=partial.correct_solver_moves.ge(1).astype(int)
    partial_summary=partial.groupby(['condition','llm_name']).agg(n=('success','size'),
        first_moves_correct=('first_move_correct','sum'),full_solves=('success','sum'))
    partial_summary.to_csv(ANALYSIS/'posthoc_first_move_diagnostic.csv')
    fig,axes=plt.subplots(1,2,figsize=(12,4))
    legal=dev.assign(no_format_or_legality_failure=~dev.failure_type.isin(['unparseable','illegal_move','generation_limit']))
    legal.groupby(['condition','llm_name']).no_format_or_legality_failure.mean().unstack('llm_name').plot.bar(ax=axes[0])
    first=(partial_summary.first_moves_correct/partial_summary.n).unstack('llm_name')
    first.plot.bar(ax=axes[1])
    for ax,title in zip(axes,['Attempts without format/legality failure','First move correct (post-hoc diagnostic)']):
        ax.set(title=title,ylim=(0,1),xlabel='',ylabel='Proportion of development attempts')
        ax.tick_params(axis='x',rotation=15)
    fig.tight_layout();fig.savefig(FIG/'development_diagnostics.png',dpi=160);plt.close(fig)
    baseline=pd.read_csv(ROOT/'data/experiments/local_pilot_v2/outcomes.csv',dtype={'puzzle_id':str})
    baseline=baseline.loc[baseline.puzzle_id.isin(dev_features.puzzle_id)&baseline.status.eq('completed')].copy()
    baseline['condition']='original_fen_uci'
    comparison=pd.concat([baseline[['condition','llm_name','success']],dev[['condition','llm_name','success']]])
    compare=comparison.groupby(['condition','llm_name']).agg(n=('success','size'),solved=('success','sum'),solve_rate=('success','mean'))
    compare.to_csv(ANALYSIS/'matched_development_comparison.csv')
    fig,ax=plt.subplots(figsize=(10,5))
    compare.solve_rate.unstack('llm_name').plot.bar(ax=ax)
    ax.set(ylabel='Full official-line solve rate',xlabel='',ylim=(0,1),title='Matched development puzzles: exploratory prompt comparison')
    ax.tick_params(axis='x',rotation=15);fig.tight_layout();fig.savefig(FIG/'development_comparison.png',dpi=160);plt.close(fig)
    selection=json.loads((OUT/'selection.json').read_text()) if (OUT/'selection.json').exists() else {'selected_condition':None}
    report={'selection':selection,'total_recorded_outcomes':len(rows),'infrastructure_errors':int(rows.status.ne('completed').sum()),
        'model_status':'Not fitted to development data. Fresh evaluation requires a condition to meet the pre-specified readiness checks.',
        'notes':['Development includes 12 known original-pilot puzzles and is exploratory.',
                 'Fresh sample excludes all 75 original-pilot IDs; 60/15 puzzle split was saved before evaluation.',
                 'JSON/UCI syntax is constrained in both revised conditions; legal choices condition additionally constrains legality.',
                 'These are protocol bundles, not an isolated causal estimate of board representation.',
                 'Thinking probe is Qwen-only, has a larger output budget, and is not eligible for protocol selection.',
                 'No solution or engine evaluation enters model inputs. Exact official-line scoring may reject legal alternatives.',
                 'The fixed random development subset contains only multi-step puzzles; mate-in-one fixtures are a separate sanity task.',
                 'First-move correctness is reported post-hoc as a descriptive diagnostic only; it does not replace the primary full-solution outcome.',
                 'Readiness checks do not establish statistical power or population representativeness.']}
    if choice_rows:
        report['first_alphabetical_choice_rates']={k:float(v) for k,v in choices.groupby('llm_name').selected_first_alphabetical_choice.mean().items()}
    evaluated=scored.loc[scored.stage.eq('evaluation')].copy()
    if not evaluated.empty:
        features=pd.read_csv(OUT/'evaluation_puzzles.csv',dtype={'puzzle_id':str})
        data=evaluated.merge(features,on='puzzle_id',validate='many_to_one')
        data.to_csv(ANALYSIS/'evaluation_modeling_table.csv',index=False)
        report['evaluation_n']=len(data)
        if len(data)==225:fit_models(data,split,report)
        else:report['model_status']='Fresh evaluation incomplete; models not fitted.'
    audit=json.loads((OUT/'audit_summary.json').read_text()) if (OUT/'audit_summary.json').exists() else {}
    report['audit']=audit
    report['sanity_audit']=json.loads((OUT/'sanity_audit_summary.json').read_text()) if (OUT/'sanity_audit_summary.json').exists() else {}
    write_json(ANALYSIS/'results_summary.json',report)
    text='''# Revised prompt experiment: board_prompt_v1

## What changed

The original FEN-only experiment, its prompt, configuration, raw data, notebook,
and figures were preserved. SHA-256 fingerprints in the new experiment folder
verify that the protected checkpoint files remain unchanged.

A separate experiment now tests FEN plus an explicit piece list with constrained
JSON/UCI output, and that same representation plus legal-move choices with output
constrained to those choices. This is a change in task assistance and response
format, not a direct replacement for the original scores.

## Design and execution

- Development: 12 puzzles (4 per rating stratum), selected deterministically from
  the original 75 before the revised model responses were observed.
- Sanity checks: side to move, any legal move, and a verified mate-in-one, each for
  White and Black. Fixtures are separate from research data.
- Direct generation: temperature 0, seed 401, 256 output tokens, 4096 context;
  Qwen thinking disabled.
- Thinking probe: Qwen only, one development puzzle per stratum, thinking enabled,
  2048 output tokens. This exploratory condition cannot select the shared protocol.
- Fresh evaluation: 75 preselected puzzles, excluding every original-pilot puzzle,
  using the original rating cutoffs and eligibility. These were reserved before
  development inference. A 60/15 puzzle train/test assignment was saved in advance.
- Readiness rule: all 36 condition attempts completed, at least 3 full solves
  across at least 2 distinct puzzles, and at least 90% format-and-legality rate.
  Choose the condition with more full solves; ties prefer the unassisted move set.
  These are operational thresholds, not a statistical power calculation.
- Every request/response is logged. Official solution sequences remain outside
  the prompt. Incorrect, illegal, unparseable, and budget-limited answers stop a
  puzzle; infrastructure errors remain unscored.

## Matched development results

'''+markdown_table(compare)+ '\n\n## First-move diagnostic (post-hoc, descriptive only)\n\n'+markdown_table(partial_summary)+ '\n\nThis does not replace full-line scoring or affect selection. The random development\nsubset happened to contain only multi-step puzzles; this limits what a small\nzero-full-success result can establish about single-move tactical selection.\n\n## Sanity results\n\n'+markdown_table(sanity_summary)+ '\n\n## Decision and modeling status\n\n```json\n'+json.dumps(report,indent=2)+'\n```\n\n## Reproduce and inspect\n\nRun the commands in `code/experiments/board_prompt_v1/README.md`. Open\n`code/revised_prompt_experiment.ipynb` for executed tables and figures. Raw logs,\nmanifests, and reserved samples are in `data/experiments/board_prompt_v1/`; the\nexisting Git ignore policy excludes data, so retain a separate backup.\n\nThe main-study sample and XGBoost remain later stages. Do not merge development\noutcomes into fresh evaluation or reinterpret assisted accuracy as unaided skill.\n'
    (ROOT/'writing/revised_prompt_experiment.md').write_text(text,encoding='utf-8')
    print(summary.to_string());print('\n'+json.dumps(report,indent=2))
    return report


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--plan-only',action='store_true')
    if parser.parse_args().plan_only:
        planned_split();print('Saved 60/15 puzzle-level evaluation split before evaluation outcomes.')
    else:main()
