"""Protocol checks: no inference calls and no research outcomes changed."""
import json
import chess
from experiment import move_body, parse_move, sanity_cases

board=chess.Board()
def payload(text, reason='stop'):
    return {'done_reason':reason,'message':{'content':text}}
assert parse_move(board,payload('{"move":"e2e4"}'),'e2e4')==('correct','e2e4')
assert parse_move(board,payload('{"move":"d2d4"}'),'e2e4')[0]=='legal_incorrect'
assert parse_move(board,payload('{"move":"e2e5"}'),'e2e4')[0]=='illegal_move'
assert parse_move(board,payload('e2e4'),'e2e4')[0]=='unparseable'
assert parse_move(board,payload('{"move":"e2e4","extra":1}'),'e2e4')[0]=='unparseable'
assert parse_move(board,payload('{"move":"e2e4"}','length'),'e2e4')[0]=='generation_limit'
for text,expected in [('e2e4','e2e4'),('e7e5','e7e5'),('g1f3','g1f3')]:
    category,move=parse_move(board,payload(json.dumps({'move':text})),expected)
    assert category=='correct';board.push_uci(move)
board=chess.Board()
assisted=move_body(board,'legal_choices_json','qwen3:8b')
assert set(assisted['format']['properties']['move']['enum'])=={m.uci() for m in board.legal_moves}
assert assisted['think'] is False
assert 'enum' not in move_body(board,'piece_list_json','gemma3:4b')['format']['properties']['move']
assert move_body(board,'legal_choices_json','qwen3:8b',True)['think'] is True
for name,board,task in sanity_cases():
    assert board.is_valid()
    if task=='mate':
        mates=[]
        for move in list(board.legal_moves):
            copy=board.copy();copy.push(move)
            if copy.is_checkmate():mates.append(move.uci())
        assert mates
        print(name,'verified mating moves:',mates)
print('Protocol checks passed: JSON, legality, scoring, sequencing, budgets, choices, thinking, sanity fixtures.')
