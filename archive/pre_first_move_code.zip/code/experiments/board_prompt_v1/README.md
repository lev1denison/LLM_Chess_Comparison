# Revised board prompt experiment, version 1

The original experiment is immutable. This directory uses new prompts, config,
runner, samples, logs, analysis, and figures. No original outcomes are relabeled.

From the repository root, use the project `.venv/Scripts/python.exe`:

```powershell
.venv/Scripts/python.exe code/experiments/board_prompt_v1/test_experiment.py
.venv/Scripts/python.exe code/experiments/board_prompt_v1/experiment.py prepare
.venv/Scripts/python.exe code/experiments/board_prompt_v1/analyze.py --plan-only
.venv/Scripts/python.exe code/experiments/board_prompt_v1/experiment.py develop
.venv/Scripts/python.exe code/experiments/board_prompt_v1/experiment.py evaluate
.venv/Scripts/python.exe code/experiments/board_prompt_v1/experiment.py audit
.venv/Scripts/python.exe code/experiments/board_prompt_v1/analyze.py
```

`evaluate` only runs if a shared direct-answer development condition meets the
readiness rule saved in config before collection. Otherwise it records the
decision and returns without evaluating the reserved puzzles. It never changes
the rule or draws another sample based on unsuccessful outcomes.

Collection is serial by model to limit resident memory, resumable by stage,
condition, puzzle and model, and protected by a manifest containing executable
code hash, prompt/configuration, model digests, and sample hashes. Do not edit
the runner or prompts after a run starts; make another experiment version.

The direct comparison uses 12 development puzzles, with identical 256-token
budgets and structured JSON/UCI syntax. `legal_choices_json` additionally lists
all legal moves and constrains the output to them. Legal moves are sorted, not
ranked by strength. This assisted condition cannot measure spontaneous legality.
The Qwen thinking probe uses only three predetermined development puzzles and a
2048-token budget; it is exploratory and excluded from selection.

All three model tags are the local installed quantized distributions. Compare
deployment behavior, not isolated family, parameter-count or quantization effects.
Full success means exact completion of every official solver move. Alternatives
are not engine-adjudicated; infrastructure errors are not chess failures.

Open `code/revised_prompt_experiment.ipynb` for the executed report and
`writing/revised_prompt_experiment.md` for the design, changes, decision and results.
Raw data is ignored by Git and must be backed up separately.

Official API references: [chat](https://docs.ollama.com/api/chat) and
[structured outputs](https://docs.ollama.com/capabilities/structured-outputs).
