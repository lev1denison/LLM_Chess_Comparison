# Hosted first-move feasibility v1

Run notebooks/06_groq120b_capability.ipynb. See config.json and prompt.txt for the frozen protocol. Requires a local Groq key in Git-ignored api_key.txt. Eight capability checks; gate requires both side checks, both legal checks and at least two of four mates, with all eight completed. Two consecutive infrastructure/budget failures stop the gate. Only a passing gate releases 24 fresh puzzles; no classifier fitting. Legal choices are assistance. No engine or answer is sent. Raw outputs are under data/experiments/groq120b_capability_v1/.
