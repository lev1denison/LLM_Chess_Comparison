# Qwen 14B capability check, version 2

Active implementation: `notebooks/05_qwen14b_capability.ipynb`. Results and methods:
`writing/qwen14b_capability_report.md`.

This version uses Qwen's recommended thinking-mode sampling: temperature 0.6,
top_p 0.95, top_k 20 and min_p 0. Seed 401, an 8192-token generation cap and
12288-token context are fixed. The model author warns that greedy decoding can
degrade performance and produce endless repetitions. This makes earlier
temperature-zero reasoning probes unsuitable as a definitive capability verdict.
See the [official model card](https://huggingface.co/Qwen/Qwen3-14B).

The initial temperature-zero 14B draft was aborted before any response was
recorded. Its manifest/config are preserved in the v1 folders, with a source
notebook ZIP in `archive/`. It was not overwritten or merged with this run.

The eight synthetic tasks, capability gate, early-stop rule and conditional
24-puzzle fresh evaluation are unchanged from v1. Both side checks, both legal
checks and at least two of four mates must pass, with all eight tasks completed.
Two consecutive generation-limit or infrastructure failures stop diagnostics.
Mates are verified by chess rules, with mirrored fixtures counted as diagnostic
checks rather than independent research observations.

All move tasks provide FEN, a piece list and legal UCI choices, with structured
output constrained to the choices. No answer key or engine evaluation is given.
The fresh sample is collected only after the gate passes, excludes all 198 prior
original/reserved/first-move IDs, and uses the official first move as its outcome.
Uniform random legal selection is the baseline. No classifiers are fitted here.

8192 tokens is a bounded local diagnostic budget, below the model card's broader
output-length recommendation. A generation-limit result therefore establishes
only that this deployment did not complete within the chosen budget. Changes in
size, reasoning and budgets cannot be isolated from one another in this check.

Raw records, gate, runtime metadata and audit are saved in
`data/experiments/qwen14b_capability_v2/`. The frozen manifest rejects changed
settings, source cells, model digests or prompt; use another version for changes.
Previous experiments are hash-checked. Raw data is Git-ignored and needs backup.
