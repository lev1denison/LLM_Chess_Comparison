# Human-rated chess difficulty and LLM performance

Victor Le — DA401 capstone

The project asks whether human-rated Lichess puzzle difficulty predicts LLM
performance and whether position features add predictive information.

## Start here

Open **[04 — First-move results](notebooks/04_first_move_results.ipynb)** for current
executed results, the exact random baseline and preliminary model status. Read
**[the current report](writing/first_move_pilot_report.md)** for methods, findings,
limitations, changes and the next research decision.

The original full-sequence pilot produced 0/225 successes. Revised prompt
development improved format and legality but produced no complete solutions.
The current experiment measures **assisted first-move correctness** as a separate
outcome. Earlier scores are unchanged; a correct first move does not imply that
a multi-step puzzle was solved.

## Notebook workflow

The next feasibility workflow is [06 — Hosted 120B capability](notebooks/06_groq120b_capability.ipynb),
with a separate [frozen protocol](experiments/groq120b_capability_v1/README.md).
It uses a locally saved Groq key in Git-ignored `api_key.txt`. It checks eight
synthetic tasks before conditionally collecting 24 fresh first-move responses.
The main research question remains difficulty versus success for one model;
cross-model comparison is optional. This small stage does not fit final classifiers.

The hosted run passed all eight capability checks. On 24 fresh puzzles it produced
11 correct first moves, four incorrect returned answers and nine requests with no
usable answer (45.8% correct across all attempts). See the
[hosted feasibility report](writing/groq120b_capability_report.md) for the full
denominators, provider errors, audit and recommended next stage.

Use the project's `.venv` Python kernel. Start Jupyter/VS Code in this repository.
Installed package versions are recorded in `requirements.txt` for environment
recreation; the current environment is already configured.

| Notebook | Purpose | When to run |
| --- | --- | --- |
| [01 — Data inspection](notebooks/01_data_inspection.ipynb) | Original audit and distributions | Historical outputs retained; rerun if needed |
| [02 — Chess validation](notebooks/02_chess_validation.ipynb) | Board legality and feature extraction | Already completed for 6,157,341 puzzles; rerun for source/method changes only |
| [03 — First-move pilot](notebooks/03_first_move_pilot.ipynb) | Review, sample, freeze, collect and audit | Requires Ollama; resumes completed collection |
| [04 — First-move results](notebooks/04_first_move_results.ipynb) | Chance comparison and eligible models | Read or rerun; no inference calls |
| [05 — Qwen 14B capability](notebooks/05_qwen14b_capability.ipynb) | Stronger reasoning deployment: simple tasks, then fresh evaluation only if ready | Separate experiment; requires `qwen3:14b` |

Local models: `gemma3:4b`, `qwen3:8b`, `llama3.1:8b`. The current prompt and
settings are in [experiments/first_move_v1](experiments/first_move_v1/README.md).
The subsequent [Qwen 14B capability check](experiments/qwen14b_capability_v2/README.md)
uses thinking and a larger generation budget; its separate
[report](writing/qwen14b_capability_report.md) records whether fresh collection is justified.

## Project layout

```text
notebooks/                       Numbered workflows (01–05)
experiments/                     Versioned prompts, configurations and protocols
data/                            Source, samples, raw logs and tables (Git-ignored)
figures/first_move_v1/            Current plots; older folders retained
writing/                         Current report and historical documents
archive/                         Verified legacy code ZIP and restoration guide
```

Former loose scripts, duplicate setup notebooks and placeholder regression code
are preserved in [the archive](archive/README.md). Existing data and figures
retain their paths. Historical reports' `code/` references refer to the restorable
archived layout.

## Data and interpretation

Source: [Lichess puzzle database](https://database.lichess.org/#puzzles). Snapshot
hashes are saved in experiment metadata. Back up `data/` separately; it is ignored
by Git and is not included in the code archive.

The current balanced 48-puzzle sample is exploratory and uses legal-move assistance
and exact official first-move matching. It does not establish population accuracy
or general LLM chess ability. Model family, size and quantization differ. Merely
fitting a classifier does not establish above-chance ability or a stable human
difficulty relationship.
