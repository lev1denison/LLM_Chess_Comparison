# My figures

I keep my current three-figure overview in `12_mistral_results/`: accuracy, separate logistic regressions and descriptive trees. I show completed GPT-OSS and Gemini results and mark Mistral as incomplete until its access and analysis gates pass. I retain earlier figures as historical checkpoints. My trees describe their training sample; I do not claim held-out prediction accuracy.
