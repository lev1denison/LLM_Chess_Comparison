# Chess difficulty and LLM success

Victor Le - DA401

**My question:** Does human-rated Lichess puzzle difficulty predict an LLM's success?
I measure assisted exact first-move correctness, rather than full puzzle solutions.

## My current step

**12 - I am checking Mistral access and reviewing my early results.**
I use [notebook 12](notebooks/12_mistral_results.ipynb) for the current overview.
My Mistral key can list models, but inference returns HTTP 429 with a limit of
**0 requests/minute**. I need a nonzero allowance before collecting its puzzles.
I have no Mistral accuracy estimate, regression or tree yet.

| My completed deployment | Correct first moves | Other answers |
| --- | --- | --- |
| GPT-OSS 120B | 21/60 (35%) | 38 incorrect legal moves; 1 format failure |
| Gemini 3.5 Flash-Lite | 32/60 (53.3%) | 26 incorrect legal moves; 2 format failures |

I audited both completed runs and fitted separate logistic regressions and
descriptive trees. Gemini's rating odds ratio is 0.51 per 500 points (95%
interval 0.29-0.90). I treat these as exploratory results on the same 60 puzzles;
different deployment settings do not establish a model-family ranking.

I review the [accuracy overview](figures/12_mistral_results/accuracy.png),
[regressions](figures/12_mistral_results/logistic_regression.png) and
[trees](figures/12_mistral_results/decision_trees.png). The plots mark Mistral
as incomplete. After reviewing the pilot, I will freeze a larger fresh sample.

## My workflow

| Stage | My work | Status |
| --- | --- | --- |
| 01 | [Inspect my data](notebooks/01_data_inspection.ipynb) | Complete |
| 02 | [Validate chess positions](notebooks/02_chess_validation.ipynb) | 6,157,341 puzzles validated |
| 03-07 | Earlier local and hosted development | Historical records |
| 08 | [Check hosted reliability](notebooks/08_check_hosted_reliability.ipynb) | Complete |
| 09 | [Collect my research sample](notebooks/09_collect_research_sample.ipynb) | GPT-OSS: 60 responses, audited |
| 10 | [Analyze my research sample](notebooks/10_analyze_research_sample.ipynb) | GPT-OSS regression and tree |
| 11 | Gemini extension | 60 responses, audited; regression and tree |
| 12 | [Check Mistral and review results](notebooks/12_mistral_results.ipynb) | Mistral blocked by zero inference allowance |

## My folders

- `notebooks/`: my ordered workflow; I use the project's `.venv` kernel.
- `experiments/`: my frozen prompts, settings and stage index.
- `data/`: my raw answers, samples, audits, usage and fitted models; Git-ignored, so I back it up separately.
- `figures/`: my numbered graphs; the current overview is stage 12.
- `writing/`: my three original PDFs, unchanged, and a short README.
- `archive/`: my previous code, notebooks and writing snapshots.

I keep keys in Git-ignored `api_key.txt`, `google_api.txt` and `mistral_api.txt`.
I read saved notebook results without rerunning API collection. Once I have
Mistral access, notebook 12 resumes saved answers and runs capability checks
before research collection. I check my account-wide allowance at
[Mistral Limits](https://admin.mistral.ai/plateforme/limits); the notebook records
experiment usage and the quota headers returned by the API.

I preserved previous response records and fitted models. I use first person in
my current Markdown writing. I have not committed or pushed this update.
